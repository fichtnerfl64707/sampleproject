



import setuptools

with open("README.md", "r") as fh: 
	long_description = fh.read()

setuptools.setup(
	name="example-pkg-fichtnerfl64707",
	version="0.0.1",
	author="fichtnerfl64707",
	author_email="florian.fichtner96@googlemail.com",
	description="A small sample package",
	long_description=long_description,
	long_description_content_type="text/markdown",
	url="https://github.com/fichtnerfl64707/sampleproject",
	packages=setuptools.find_packages(),
	classifiers=[
		"Programming Language :: Python :: 3",
		"License :: OSI Approved :: MIT License",
		"Operating System :: OS Independent",
	],
	python_requires='>=3.6',
)
